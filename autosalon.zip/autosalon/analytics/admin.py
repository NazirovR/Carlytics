from django.contrib import admin
from .models import Client, Visit

admin.site.register(Client)
admin.site.register(Visit)
